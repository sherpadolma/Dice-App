package com.example.healthapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
